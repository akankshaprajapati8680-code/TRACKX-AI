# Firmware (ESP32) - SKELETON, NOT HARDWARE-TESTED

These Arduino sketches show the intended structure of the two nodes
(ESP-NOW link). They have **not** been run on real hardware yet.
Pin numbers, probe frequency and ADC rate are placeholders that will be fixed
during prototyping. A proper ultrasonic probe + pulser-receiver + signal
conditioning is required; an HC-SR04 cannot inspect steel rails.

* `tx_node/tx_node.ino` - triggers the pulser and tells the RX node a capture started.
* `rx_node/rx_node.ino` - captures N ADC samples after the trigger and streams them to the laptop (USB serial) for `src/dashboard.py` / a bridge script.

Note: the ESP32's internal ADC (~ <1 Msps usable) is far too slow for MHz ultrasonic
signals. A real build needs an external high-speed ADC (or an analog front-end that
envelope-detects / down-converts the signal). Treat this code as protocol scaffolding.
